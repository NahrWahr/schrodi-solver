nx=500
nt= 10000
dx=1/nx
dt=dx * 1e-4
